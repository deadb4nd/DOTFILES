import * as pdfjsLib from "./vendor/pdf.mjs";

pdfjsLib.GlobalWorkerOptions.workerSrc = "./vendor/pdf.worker.mjs";

const PDF_URL = "CENNIK-2026 CDA.pdf";
const PRODUCTS = window.PRODUCTS || [];
const byPage = new Map();
for (const p of PRODUCTS) {
  if (!byPage.has(p.page)) byPage.set(p.page, []);
  byPage.get(p.page).push(p);
}
const byCode = new Map(PRODUCTS.map((p) => [p.code, p]));

function normText(s) {
  return (s || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\u0142/g, 'l')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function codeExtras(code) {
  const c = code.toUpperCase();
  let x = '';
  if (c.indexOf('LH') !== -1 || /(^|-)L($|-)/.test(c)) x += ' lewy lewa lewej';
  if (c.indexOf('RH') !== -1 || /(^|-)R($|-)/.test(c)) x += ' prawy prawa prawej';
  return x;
}

for (const p of PRODUCTS) {
  p._code = normText(p.code);
  p._codeC = p._code.replace(/ /g, '');
  p._desc = normText(p.desc || '');
  p._q = normText([p.code, p.desc, p.info, p.group].join(' ')) + codeExtras(p.code);
  p._words = Array.from(new Set(p._q.split(' '))).filter(Boolean);
}

/* group finish/size variants (e.g. TGHU90RH-PC, -SC, -WH...) into one family */
const families = [];
{
  const fm = new Map();
  for (const p of PRODUCTS) {
    const parts = p.code.split("-");
    const base = parts.length > 1 ? parts.slice(0, -1).join("-") : p.code;
    const sig = normText((p.desc || p.info || "").trim());
    const key = p.page + "|" + base + "|" + sig;
    let f = fm.get(key);
    if (!f) {
      f = { base, page: p.page, items: [] };
      fm.set(key, f);
      families.push(f);
    }
    f.items.push(p);
    p._fam = f;
  }
  for (const f of families) {
    const first = f.items[0];
    f.first = first;
    if (f.items.length === 1) f.base = first.code;
    const desc = first.desc || first.info || "";
    f._desc = normText(desc);
    f._q =
      normText([f.base, f.items.map((p) => p.code).join(" "), desc, first.info, first.group].join(" ")) +
      f.items.map((p) => codeExtras(p.code)).join("");
    f._words = Array.from(new Set(f._q.split(" "))).filter(Boolean);
    f._baseC = normText(f.base).replace(/ /g, "");
    f._itemC = f.items.map((p) => p._codeC);
    f.options = f.items.map((p) => ({
      code: p.code,
      suffix: p.code.split("-").pop(),
      price: p.price,
      prod: p,
    }));
    const withN = f.items
      .filter((p) => p.price)
      .map((p) => ({ s: p.price, n: parseFloat(p.price.replace(/\s/g, "").replace(",", ".")) }))
      .filter((o) => !isNaN(o.n));
    withN.sort((a, b) => a.n - b.n);
    f.price = withN.length
      ? withN[0].n === withN[withN.length - 1].n
        ? withN[0].s
        : withN[0].s + "–" + withN[withN.length - 1].s
      : "";
  }
}

function shortDesc(f) {
  const d = ((f.first.desc || f.first.info || "") + "").trim();
  const re =
    /\s(?:materiał|grubość|max|zalecan|długoś|szerokoś|wysokoś|produkt|mocowan|średnic|wag|sił|kolor|wykończ|mat)[a-ząćęłńóśźż]*[ .:]/gi;
  let cut = d.length;
  let m;
  while ((m = re.exec(d))) {
    if (d.slice(0, m.index).trim().length >= 12) {
      cut = m.index;
      break;
    }
  }
  let s = d.slice(0, cut).trim();
  if (s.length < 12) s = d;
  s = s
    .replace(/[\s–-]+$/, "")
    .replace(/\s(?:z|ze|do|w|we|i|na|o|dla|oraz)$/i, "")
    .trim();
  if (s.length > 90) s = s.slice(0, 90).replace(/\s\S*$/, "") + "…";
  return s;
}

const SYN = {
  klamka: 'uchwyt',
  klamki: 'uchwyt',
  klamke: 'uchwyt',
  galeka: 'uchwyt',
  szyba: 'szklo',
  szyby: 'szklo',
  szybe: 'szklo',
  lusterko: 'lustro',
  zawiasy: 'zawias',
  zawiasow: 'zawias',
};

function expandToken(t) {
  const base = stemPl(t);
  const out = [t];
  if (SYN[t]) out.push(SYN[t]);
  else if (SYN[base]) out.push(SYN[base]);
  return Array.from(new Set(out));
}

function stemPl(w) {
  if (w.length <= 4) return w;
  return w.replace(
    /(ami|ach|owi|ego|emu|owy|owa|owe|ych|ymi|iej|iego|ów|om|em|ej|ie|ia|iu|ow|y|a|i|u|e|ą|ę|o)$/,
    '',
  );
}

function wordHit(w, t, st) {
  if (w === t || w.indexOf(t) === 0) return true;
  if (t.length >= 4 && w.length >= 4) {
    if (t.indexOf(w) === 0) return true;
    const n = Math.min(t.length, w.length);
    let k = 0;
    while (k < n && t[k] === w[k]) k++;
    if (k >= 4) return true;
  }
  if (st.length >= 3) {
    const sw = stemPl(w);
    if (sw.length >= 3) {
      if (sw === st || sw.indexOf(st) === 0 || st.indexOf(sw) === 0) return true;
      const n = Math.min(st.length, sw.length);
      let k = 0;
      while (k < n && st[k] === sw[k]) k++;
      if (k >= 4) return true;
    }
  }
  return false;
}

function tokenMatch(words, e) {
  const st = stemPl(e);
  for (const w of words) {
    if (wordHit(w, e, st)) return true;
  }
  return false;
}

const pagesEl = document.getElementById("pages");
const viewerEl = document.getElementById("viewer");
const loadingEl = document.getElementById("loading");
const loadPct = document.getElementById("load-pct");
const toastEl = document.getElementById("toast");

let pdf = null;
let baseScale = 1;
let DPR = Math.min(window.devicePixelRatio || 1, 2);
const MIN_ZOOM = 0.5;
const MAX_ZOOM = 4;
let zoom = 1;
const MAX_CANVAS_W = 4200;
const pageRecords = []; // {num, div, canvas, ph, rendered, scale, buttons}
let renderToken = 0;

/* ------------------------------------------------------------------ cart */
const STORE_KEY = "cennik-cart-v2";
let cart = {};
try {
  cart = JSON.parse(localStorage.getItem(STORE_KEY) || "{}") || {};
} catch {
  cart = {};
}
if (typeof cart !== "object" || Array.isArray(cart)) cart = {};

function saveCart() {
  try {
    localStorage.setItem(STORE_KEY, JSON.stringify(cart));
  } catch {}
}

function cartQty(code) {
  return cart[code] || 0;
}

function addToCart(code, delta = 1) {
  const q = (cart[code] || 0) + delta;
  if (q <= 0) delete cart[code];
  else cart[code] = q;
  saveCart();
  refreshCart();
  return q;
}

function refreshCart() {
  // badges + minus buttons on rendered page controls
  for (const rec of pageRecords) {
    for (const b of rec.buttons) {
      const q = cartQty(b.code);
      b.el.classList.toggle("in-cart", q > 0);
      b.el.dataset.qty = q;
      b.el.title =
        q > 0
          ? `${b.code} — w koszyku: ${q} (klik = wiecej)`
          : `${b.code} — dodaj`;
      b.dec.style.display = q > 0 ? "" : "none";
    }
  }
  renderCartPanel();
}

/* --------------------------------------------------------------- ui bits */
function toast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.remove("hidden");
  requestAnimationFrame(() => toastEl.classList.add("show"));
  clearTimeout(toast._t);
  toast._t = setTimeout(() => {
    toastEl.classList.remove("show");
    setTimeout(() => toastEl.classList.add("hidden"), 220);
  }, 1400);
}

function orderText() {
  return Object.keys(cart)
    .map((c) => `${c} - ${cart[c]}`)
    .join("\n");
}

function priceNum(p) {
  if (!p || !p.price || p.price === "zapytanie") return null;
  const n = parseFloat(p.price.replace(/\s/g, "").replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

function fmt(n) {
  return (
    n.toLocaleString("pl-PL", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }) + " PLN"
  );
}

/* ---------------------------------------------------------- cart sidebar */
const cartPanel = document.getElementById("cart");
const cartItemsEl = document.getElementById("cart-items");
const cartCountEl = document.getElementById("cart-count");
const cartTotalEl = document.getElementById("cart-total");
const orderTextEl = document.getElementById("order-text");

function renderCartPanel() {
  const codes = Object.keys(cart);
  cartCountEl.textContent = codes.reduce((s, c) => s + cart[c], 0);
  let total = 0;
  let unknown = false;
  for (const c of codes) {
    const p = byCode.get(c);
    const v = priceNum(p);
    if (v == null) unknown = true;
    else total += v * cart[c];
  }
  cartTotalEl.textContent = fmt(total) + (unknown ? " + zapytanie" : "");

  if (codes.length === 0) {
    cartItemsEl.innerHTML =
      '<div class="cart-empty">Koszyk jest pusty.<br>Kliknij <b>+</b> przy produkcie w katalogu.</div>';
    orderTextEl.value = "";
    return;
  }

  cartItemsEl.innerHTML = "";
  for (const code of codes) {
    const p = byCode.get(code) || { code, info: "", price: "" };
    const row = document.createElement("div");
    row.className = "cart-row";
    const priceTxt =
      p.price === "zapytanie"
        ? "cena: na zapytanie"
        : priceNum(p) != null
          ? fmt(priceNum(p))
          : "";
    row.innerHTML = `
      <div class="c-code">${escapeHtml(code)}</div>
      <div class="qty">
        <button data-a="-1">−</button><b>${cart[code]}</b><button data-a="1">+</button>
      </div>
      ${p.info ? `<div class="c-info">${escapeHtml(p.info)}</div>` : ""}
      ${priceTxt ? `<div class="c-price">${priceTxt}</div>` : ""}
      <button class="danger" data-remove>Usuń</button>`;
    row.querySelector('[data-a="-1"]').onclick = () => addToCart(code, -1);
    row.querySelector('[data-a="1"]').onclick = () => addToCart(code, 1);
    row.querySelector("[data-remove]").onclick = () => {
      delete cart[code];
      saveCart();
      refreshCart();
    };
    cartItemsEl.appendChild(row);
  }
  orderTextEl.value = orderText();
}

function escapeHtml(s) {
  return String(s).replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
}

function openCart(open) {
  cartPanel.classList.toggle("closed", !open);
}
document.getElementById("cart-btn").onclick = () =>
  openCart(cartPanel.classList.contains("closed"));
document.getElementById("cart-close").onclick = () => openCart(false);

document.getElementById("copy-btn").onclick = async () => {
  const txt = orderText();
  if (!txt) return toast("Koszyk jest pusty");
  try {
    await navigator.clipboard.writeText(txt);
    toast("Skopiowano!");
  } catch {
    orderTextEl.removeAttribute("readonly");
    orderTextEl.select();
    document.execCommand("copy");
    orderTextEl.setAttribute("readonly", "");
    toast("Skopiowano!");
  }
};

document.getElementById("download-btn").onclick = () => {
  const txt = orderText();
  if (!txt) return toast("Koszyk jest pusty");
  const blob = new Blob([txt + "\n"], { type: "text/plain;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "zamowienie.txt";
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  toast("Pobrano zamowienie.txt");
};

document.getElementById("clear-btn").onclick = () => {
  if (!Object.keys(cart).length) return;
  if (confirm("Wyczyścić cały koszyk?")) {
    cart = {};
    saveCart();
    refreshCart();
  }
};

/* ------------------------------------------------------------- rendering */
function fitScale() {
  const avail = Math.max(320, viewerEl.clientWidth - 32);
  return Math.min(2.4, Math.max(0.4, avail / 595.276));
}

function computeScale() {
  return fitScale() * zoom;
}

function makeButton(rec, prod) {
  const wrap = document.createElement("div");
  wrap.className = "addctl";
  wrap.style.left = (prod.x + prod.w + 3) * rec.scale + "px";
  wrap.style.top = prod.y * rec.scale + "px";

  const el = document.createElement("button");
  el.className = "addbtn";
  const q = cartQty(prod.code);
  el.classList.toggle("in-cart", q > 0);
  el.dataset.qty = q;
  el.title = `${prod.code}${prod.price ? " · " + prod.price + " PLN" : ""} — dodaj`;
  el.onclick = (ev) => {
    ev.preventDefault();
    ev.stopPropagation();
    const nq = addToCart(prod.code, 1);
    toast(`${prod.code} dodano (${nq})`);
  };

  const dec = document.createElement("button");
  dec.className = "decbtn";
  dec.textContent = "−";
  dec.title = `${prod.code} — odejmij`;
  dec.style.display = q > 0 ? "" : "none";
  dec.onclick = (ev) => {
    ev.preventDefault();
    ev.stopPropagation();
    const nq = addToCart(prod.code, -1);
    toast(nq > 0 ? `${prod.code} (${nq})` : `${prod.code} usunieto`);
  };

  wrap.appendChild(el);
  wrap.appendChild(dec);
  rec.buttons.push({ el, dec, wrap, code: prod.code });
  return wrap;
}

function cancelRender(rec) {
  if (rec.task) {
    try {
      rec.task.cancel();
    } catch (e) {}
    rec.task = null;
  }
}

async function renderPage(rec) {
  if (rec.rendered || rec.rendering) return;
  rec.rendering = true;
  const token = (rec.token = ++renderToken);
  try {
    const page = await pdf.getPage(rec.num);
    if (rec.token !== token) return; // superseded by resize
    const scale = rec.scale;
    const dprEff = Math.max(0.5, Math.min(DPR, MAX_CANVAS_W / (rec.pw * scale)));
    const vp = page.getViewport({ scale: scale * dprEff });
    const canvas = rec.canvas;
    canvas.width = Math.floor(vp.width);
    canvas.height = Math.floor(vp.height);
    canvas.style.width = vp.width / dprEff + "px";
    canvas.style.height = vp.height / dprEff + "px";
    rec.div.style.width = vp.width / dprEff + "px";
    rec.div.style.height = vp.height / dprEff + "px";
    const ctx = canvas.getContext("2d", { alpha: false });
    rec.task = page.render({ canvasContext: ctx, viewport: vp });
    await rec.task.promise;
    rec.task = null;
    if (rec.token !== token) return;
    rec.ph.style.display = "none";
    rec.buttons = [];
    const prods = byPage.get(rec.num) || [];
    for (const prod of prods) rec.div.appendChild(makeButton(rec, prod));
    rec.rendered = true;
  } catch (e) {
    if (!e || e.name !== "RenderingCancelledException") console.error("render page", rec.num, e);
  } finally {
    if (rec.token === token) rec.rendering = false;
  }
}

function unrenderPage(rec) {
  // cancel any in-flight render so pages scrolled past don't pile up
  if (rec.task) cancelRender(rec);
  if (!rec.rendered) {
    rec.rendering = false;
    return;
  }
  rec.rendering = false;
  rec.canvas.width = 0;
  rec.canvas.height = 0;
  rec.canvas.style.width = "";
  rec.canvas.style.height = "";
  for (const b of rec.buttons) b.wrap.remove();
  rec.buttons = [];
  rec.ph.style.display = "";
  rec.rendered = false;
}

function layout() {
  const scale = computeScale();
  DPR = Math.min(window.devicePixelRatio || 1, 2);
  for (const rec of pageRecords) {
    rec.scale = scale;
    cancelRender(rec);
    rec.rendered = false;
    rec.rendering = false;
    for (const b of rec.buttons) b.wrap.remove();
    rec.buttons = [];
    rec.ph.style.display = "";
    rec.canvas.width = 0;
    rec.canvas.height = 0;
    rec.div.style.width = rec.pw * scale + "px";
    rec.div.style.height = rec.ph_pdf * scale + "px";
  }
  observer.disconnect();
  for (const rec of pageRecords) observer.observe(rec.div);
}

let resizeTimer = null;
window.addEventListener("resize", () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    if (pdf) layout();
  }, 250);
});

function relayoutKeepPos() {
  const before = viewerEl.scrollHeight || 1;
  const ratio = viewerEl.scrollTop / before;
  layout();
  viewerEl.scrollTop = ratio * (viewerEl.scrollHeight || 1);
}

const zoomResetEl = document.getElementById("zoom-reset");
function setZoom(z) {
  zoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, z));
  zoomResetEl.textContent = Math.round(zoom * 100) + "%";
  const ui = Math.min(1.6, Math.max(1, zoom));
  document.documentElement.style.setProperty("--ui", ui.toFixed(3));
  if (pdf) relayoutKeepPos();
}
document.getElementById("zoom-in").onclick = () => setZoom(zoom * 1.25);
document.getElementById("zoom-out").onclick = () => setZoom(zoom / 1.25);
zoomResetEl.onclick = () => setZoom(1);

/* --------------------------------------------------------------- guide */
const guideEl = document.getElementById("guide");
function openGuide() {
  guideEl.classList.remove("hidden");
}
function closeGuide() {
  guideEl.classList.add("hidden");
  try {
    localStorage.setItem("cennik-guide-seen", "1");
  } catch (e) {}
}
document.getElementById("help-btn").onclick = openGuide;
document.getElementById("guide-x").onclick = closeGuide;
document.getElementById("guide-close").onclick = closeGuide;
guideEl.addEventListener("click", (e) => {
  if (e.target === guideEl) closeGuide();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !guideEl.classList.contains("hidden")) closeGuide();
});
try {
  if (!localStorage.getItem("cennik-guide-seen")) openGuide();
} catch (e) {}

/* ------------------------------------------------------------ observer */
const observer = new IntersectionObserver(
  (entries) => {
    for (const en of entries) {
      const rec = pageRecords[Number(en.target.dataset.page) - 1];
      if (!rec) continue;
      if (en.isIntersecting) renderPage(rec);
      else unrenderPage(rec);
    }
  },
  { root: viewerEl, rootMargin: "1200px 0px" },
);

/* -------------------------------------------------------------- search */
const searchEl = document.getElementById("search");
const resultsEl = document.getElementById("search-results");

const imgBoxCache = new Map();
const pageCanvasCache = new Map();
const thumbCache = new Map();
const MAX_PAGE_CANVAS = 6;

async function getImageBoxes(pageNum) {
  if (imgBoxCache.has(pageNum)) return imgBoxCache.get(pageNum);
  const pg = await pdf.getPage(pageNum);
  const { fnArray, argsArray } = await pg.getOperatorList();
  const OPS = pdfjsLib.OPS;
  const IMG = new Set(
    [
      OPS.paintImageXObject,
      OPS.paintInlineImageXObject,
      OPS.paintImageMaskXObject,
      OPS.paintImageXObjectRepeat,
      OPS.paintImageMaskXObjectRepeat,
    ].filter((x) => x !== undefined),
  );
  const H = pg.getViewport({ scale: 1 }).height;
  const stack = [];
  let ctm = [1, 0, 0, 1, 0, 0];
  const mul = (m, n) => [
    m[0] * n[0] + m[2] * n[1],
    m[1] * n[0] + m[3] * n[1],
    m[0] * n[2] + m[2] * n[3],
    m[1] * n[2] + m[3] * n[3],
    m[0] * n[4] + m[2] * n[5] + m[4],
    m[1] * n[4] + m[3] * n[5] + m[5],
  ];
  const boxes = [];
  for (let i = 0; i < fnArray.length; i++) {
    const fn = fnArray[i];
    if (fn === OPS.save) stack.push(ctm.slice());
    else if (fn === OPS.restore) ctm = stack.pop() || ctm;
    else if (fn === OPS.transform) {
      const a = argsArray[i];
      ctm = mul(ctm, [a[0], a[1], a[2], a[3], a[4], a[5]]);
    } else if (IMG.has(fn)) {
      const pts = [
        [0, 0],
        [1, 0],
        [0, 1],
        [1, 1],
      ].map(([x, y]) => [
        ctm[0] * x + ctm[2] * y + ctm[4],
        ctm[1] * x + ctm[3] * y + ctm[5],
      ]);
      const xs = pts.map((p) => p[0]);
      const ys = pts.map((p) => p[1]);
      const x = Math.min(...xs);
      const y = Math.min(...ys);
      const w = Math.max(...xs) - x;
      const h = Math.max(...ys) - y;
      // convert PDF user space (bottom-left) to top-down, keep left-column product photos
      const box = { x, y: H - (y + h), w, h };
      if (box.x < 230 && box.w >= 18 && box.w < 450 && box.h >= 30 && box.h < 340) {
        boxes.push(box);
      }
    }
  }
  imgBoxCache.set(pageNum, boxes);
  return boxes;
}

async function getPageCanvas(pageNum) {
  if (pageCanvasCache.has(pageNum)) return pageCanvasCache.get(pageNum);
  const p = (async () => {
    const pg = await pdf.getPage(pageNum);
    const vp = pg.getViewport({ scale: 1 });
    const c = document.createElement("canvas");
    c.width = Math.floor(vp.width);
    c.height = Math.floor(vp.height);
    await pg.render({ canvasContext: c.getContext("2d"), viewport: vp }).promise;
    return c;
  })();
  pageCanvasCache.set(pageNum, p);
  while (pageCanvasCache.size > MAX_PAGE_CANVAS) {
    const k = pageCanvasCache.keys().next().value;
    if (k === pageNum) break;
    pageCanvasCache.delete(k);
  }
  return p;
}

function blockFor(prod) {
  const list = (byPage.get(prod.page) || []).slice().sort((a, b) => a.y - b.y);
  let cur = null;
  const blocks = [];
  for (const it of list) {
    if (cur && it.y - cur.maxy <= 30) {
      cur.items.push(it);
      cur.maxy = it.y;
    } else {
      cur = { items: [it], miny: it.y, maxy: it.y };
      blocks.push(cur);
    }
  }
  return blocks.find((b) => b.items.indexOf(prod) !== -1) || { miny: prod.y, maxy: prod.y };
}

async function thumbFor(prod) {
  if (thumbCache.has(prod.code)) return thumbCache.get(prod.code);
  const p = (async () => {
    try {
      const boxes = await getImageBoxes(prod.page);
      if (!boxes.length) return null;
      const b = blockFor(prod);
      let best = null;
      let bestScore = 1e9;
      for (const box of boxes) {
        const by1 = box.y + box.h;
        const overlap = Math.max(0, Math.min(by1, b.maxy) - Math.max(box.y, b.miny));
        const dist =
          overlap > 0 ? -overlap : Math.min(Math.abs(box.y - b.miny), Math.abs(by1 - b.maxy));
        if (dist < bestScore) {
          bestScore = dist;
          best = box;
        }
      }
      if (!best) return null;
      const src = await getPageCanvas(prod.page);
      const TW = 76;
      const TH = 76;
      const tc = document.createElement("canvas");
      tc.width = TW;
      tc.height = TH;
      const ctx = tc.getContext("2d");
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, TW, TH);
      const s = Math.min(TW / best.w, TH / best.h);
      const dw = best.w * s;
      const dh = best.h * s;
      ctx.drawImage(src, best.x, best.y, best.w, best.h, (TW - dw) / 2, (TH - dh) / 2, dw, dh);
      return tc.toDataURL("image/png");
    } catch (e) {
      return null;
    }
  })();
  thumbCache.set(prod.code, p);
  return p;
}

let resObs = null;
function attachThumbs() {
  if (resObs) resObs.disconnect();
  resObs = new IntersectionObserver(
    (entries) => {
      for (const en of entries) {
        if (!en.isIntersecting) continue;
        const im = en.target;
        resObs.unobserve(im);
        const prod = byCode.get(im.dataset.code);
        if (!prod) continue;
        thumbFor(prod).then((url) => {
          if (url) im.src = url;
        });
      }
    },
    { root: resultsEl, rootMargin: "300px 0px" },
  );
  for (const im of resultsEl.querySelectorAll("img.thumb")) resObs.observe(im);
}

function runSearch(q) {
  const nq = normText(q);
  if (!nq) {
    resultsEl.classList.add("hidden");
    resultsEl.innerHTML = "";
    return;
  }
  const rawTokens = nq.split(" ").filter(Boolean);
  const tokens = rawTokens.map((t) => ({ raw: t, ex: expandToken(t) }));
  const nqC = nq.replace(/ /g, "");
  const wantLeft = rawTokens.some((t) => t.indexOf("lew") === 0);
  const wantRight = rawTokens.some((t) => t.indexOf("praw") === 0);

  const scored = [];
  for (const f of families) {
    let ok = true;
    for (const t of tokens) {
      let hit = false;
      for (const e of t.ex) {
        if (tokenMatch(f._words, e)) {
          hit = true;
          break;
        }
      }
      if (!hit) {
        ok = false;
        break;
      }
    }
    if (!ok) continue;

    let s = tokens.length * 2;
    if (f._baseC === nqC) s += 1000;
    else if (f._baseC.indexOf(nqC) === 0) s += 600;
    else if (f._baseC.indexOf(nqC) !== -1) s += 350;
    if (f._itemC.some((c) => c === nqC)) s += 900;
    else if (f._itemC.some((c) => c.indexOf(nqC) === 0)) s += 500;

    const baseWords = normText(f.base).split(" ");
    const descWords = f._desc.split(" ");
    for (const t of rawTokens) {
      if (baseWords.some((w) => w.indexOf(t) === 0)) s += 40;
      if (descWords.some((w) => w.indexOf(t) === 0)) s += 15;
    }
    if (wantLeft && f._baseC.indexOf("lh") !== -1) s += 80;
    if (wantRight && f._baseC.indexOf("rh") !== -1) s += 80;
    scored.push([s, f]);
  }
  scored.sort((a, b) => b[0] - a[0]);
  const hits = scored.slice(0, 40).map((x) => x[1]);

  resultsEl.innerHTML =
    hits
      .map((f) => {
        const multi = f.items.length > 1;
        const opts = multi
          ? `<span class="opts">${f.options
              .map(
                (o) =>
                  `<button class="opt" data-code="${escapeHtml(o.code)}" data-page="${f.page}" title="Dodaj ${escapeHtml(o.code)} — ${escapeHtml(o.suffix)}">+${escapeHtml(o.suffix)}</button>`,
              )
              .join("")}</span>`
          : "";
        return `
    <div class="res" data-code="${escapeHtml(f.first.code)}" data-page="${f.page}">
      <img class="thumb" data-code="${escapeHtml(f.first.code)}" alt="">
      <span class="rtext">
        <span class="rhead"><b>${escapeHtml(f.base)}</b> <span class="rdesc">${escapeHtml(shortDesc(f))}</span></span>
        ${multi ? `<span class="optlabel">${f.items.length} wariantów — kliknij, aby dodać:</span>` : ""}${opts}
      </span>
      <span class="rmeta">s.${f.page}${f.price ? "<br><b>" + escapeHtml(f.price) + "</b> PLN" : ""}</span>
    </div>`;
      })
      .join("") ||
    '<div class="res"><span class="meta">Brak wyników — spróbuj innej nazwy</span></div>';
  resultsEl.classList.remove("hidden");
  attachThumbs();
  resultsEl.querySelectorAll(".opt").forEach((el) => {
    el.onclick = (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      const n = addToCart(el.dataset.code, 1);
      toast(`${el.dataset.code} dodano (${n})`);
    };
  });
  resultsEl.querySelectorAll(".res[data-code]").forEach((el) => {
    el.onclick = () => {
      goToProduct(el.dataset.code, Number(el.dataset.page));
      resultsEl.classList.add("hidden");
      searchEl.blur();
    };
  });
}

async function goToProduct(code, page) {
  const rec = pageRecords[page - 1];
  const prod = byCode.get(code);
  if (!rec || !prod) return;

  // center the product (not just the top of the page) in the viewport.
  // jump instantly: a smooth scroll would render (and pile up) every page
  // it passes through, starving the page we actually care about.
  const target =
    rec.div.offsetTop + prod.y * rec.scale - viewerEl.clientHeight / 2;
  viewerEl.style.scrollBehavior = "auto";
  viewerEl.scrollTo({ top: Math.max(0, target), behavior: "auto" });
  viewerEl.style.scrollBehavior = "";

  let found = rec.buttons.find((b) => b.code === code);
  for (let i = 0; i < 40 && !found; i++) {
    await new Promise((r) => setTimeout(r, 100));
    found = rec.buttons.find((b) => b.code === code);
    if (!found && !rec.rendering) renderPage(rec);
  }
  if (found) {
    found.el.classList.add("flash");
    setTimeout(() => found.el.classList.remove("flash"), 1800);
  }
  spotlight(rec, prod);
}

function spotlight(rec, prod) {
  rec.div.querySelectorAll(".spotlight").forEach((n) => n.remove());
  const pad = 4;
  const d = document.createElement("div");
  d.className = "spotlight";
  d.style.left = (prod.x - pad) * rec.scale + "px";
  d.style.top = (prod.y - pad) * rec.scale + "px";
  d.style.width = (prod.w + pad * 2) * rec.scale + "px";
  d.style.height = (prod.h + pad * 2) * rec.scale + "px";
  rec.div.appendChild(d);
  setTimeout(() => d.remove(), 3600);
}

searchEl.addEventListener("input", (e) => runSearch(e.target.value));
document.addEventListener("keydown", (e) => {
  if (e.key === "/" && document.activeElement !== searchEl) {
    e.preventDefault();
    searchEl.focus();
    searchEl.select();
  }
});
searchEl.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    resultsEl.classList.add("hidden");
    searchEl.blur();
  }
  if (e.key === "Enter") {
    const first = resultsEl.querySelector(".res[data-code]");
    if (first) {
      goToProduct(first.dataset.code, Number(first.dataset.page));
      resultsEl.classList.add("hidden");
    }
  }
});
document.addEventListener("click", (e) => {
  if (!e.target.closest(".search-wrap")) resultsEl.classList.add("hidden");
});

/* ---------------------------------------------------------------- boot */
async function boot() {
  try {
    const task = pdfjsLib.getDocument({ url: PDF_URL });
    task.onProgress = ({ loaded, total }) => {
      if (total) loadPct.textContent = Math.round((loaded / total) * 100) + "%";
    };
    pdf = await task.promise;
  } catch (err) {
    loadingEl.innerHTML =
      "Nie udalo sie wczytac PDF.<br><small>" +
      "Uruchom lokalny serwer: <code>python3 -m http.server 8000</code> " +
      "i otworz <code>http://localhost:8000</code></small>";
    console.error(err);
    return;
  }

  const scale = computeScale();
  const nums = Array.from({ length: pdf.numPages }, (_, i) => i + 1);
  const sizes = await Promise.all(
    nums.map(async (n) => {
      const page = await pdf.getPage(n);
      const vp = page.getViewport({ scale: 1 });
      return { n, w: vp.width, h: vp.height };
    }),
  );
  for (const { n, w, h } of sizes) {
    const div = document.createElement("div");
    div.className = "page";
    div.dataset.page = n;
    div.style.width = w * scale + "px";
    div.style.height = h * scale + "px";
    const canvas = document.createElement("canvas");
    const ph = document.createElement("div");
    ph.className = "ph";
    ph.textContent = "strona " + n;
    div.appendChild(canvas);
    div.appendChild(ph);
    pagesEl.appendChild(div);
    pageRecords.push({
      num: n,
      div,
      canvas,
      ph,
      rendered: false,
      rendering: false,
      buttons: [],
      scale,
      pw: w,
      ph_pdf: h,
    });
  }
  loadingEl.classList.add("hidden");
  for (const rec of pageRecords) observer.observe(rec.div);
  renderCartPanel();
}

boot();
