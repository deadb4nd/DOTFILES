#!/usr/bin/env python3
"""Extract product codes + prices + on-page coordinates from the CDA price list PDF."""
import json, re, xml.etree.ElementTree as ET

NS = '{http://www.w3.org/1999/xhtml}'
CODE_RE = re.compile(r'^[A-Z0-9][A-Z0-9\-/\.]{2,26}$')
PRICE_RE = re.compile(r'^\d{1,3}(?:[ ]?\d{3})*(?:[.,]\d{2})?$')
PRICE_ATTACHED_RE = re.compile(r'^(\d{1,3}(?:[ ]?\d{3})*(?:[.,]\d{2})?)PLN$', re.I)
EAN_RE = re.compile(r'^\d{8,14}$')
CURRENCY = {'PLN', 'NET', 'net'}

STOP = {
    'CENNIK', 'ZDJĘCIE', 'OPIS', 'TOWARU', 'KOD', 'WYKOŃCZENIE', 'CENA', 'PLN',
    'GRUBOŚĆ', 'SZKŁA', 'MATERIAŁ', 'WYMIARY', 'NETTO', 'NOW', 'CDABUFAB.PL',
    'NEW', 'USŁUGA', 'CENNIKU',
}


def clean_xml(path, out):
    with open(path, 'rb') as f:
        data = f.read()
    data = re.sub(rb'[\x00-\x08\x0b\x0c\x0e-\x1f]', b'', data)
    data = re.sub(rb'&(?![a-zA-Z]+;|#\d+;)', b'&amp;', data)
    with open(out, 'wb') as f:
        f.write(data)
    return out


EXTRA_CODES = {'FCMTS', '9002'}


CODE_MIN_X = 250


def is_code(t, x0):
    if t in STOP or len(t) < 2:
        return False
    if len(t) == 2:  # e.g. U1, U2, U4 (seal thickness codes)
        return x0 >= CODE_MIN_X and bool(re.match(r'^[A-Z]\d$', t))
    if not CODE_RE.match(t):
        return False
    if re.match(r'^RAL\d+$', t):
        return False
    has_a = any(c.isalpha() for c in t)
    has_d = any(c.isdigit() for c in t)
    if len(t) >= 4 and has_a and (has_d or '-' in t or '/' in t or '.' in t):
        return True
    if x0 < 250:  # relaxed rules only inside the product-code column
        return False
    if t in EXTRA_CODES:
        return True
    if has_a and has_d and re.match(r'^[A-Z]{1,3}\d{1,3}$', t):
        return True
    return False


def rows_of(page):
    words = []
    for w in page.iter(NS + 'word'):
        t = (w.text or '').strip()
        if not t:
            continue
        words.append({
            't': t, 'x0': float(w.get('xMin')), 'x1': float(w.get('xMax')),
            'y0': float(w.get('yMin')), 'y1': float(w.get('yMax')),
        })
    words.sort(key=lambda w: (w['y0'], w['x0']))
    rows = []
    for w in words:
        placed = False
        for r in rows:
            if abs(r['y'] - (w['y0'] + w['y1']) / 2) <= 6.5:
                r['words'].append(w)
                n = len(r['words'])
                r['y'] = (r['y'] * (n - 1) + (w['y0'] + w['y1']) / 2) / n
                placed = True
                break
        if not placed:
            rows.append({'y': (w['y0'] + w['y1']) / 2, 'words': [w]})
    for r in rows:
        r['words'].sort(key=lambda w: w['x0'])
    rows.sort(key=lambda r: r['y'])
    return rows


def main():
    clean_xml('cennik_bbox.xml', 'cennik_bbox_clean.xml')
    root = ET.parse('cennik_bbox_clean.xml').getroot()

    pages = []
    for pi, page in enumerate(root.iter(NS + 'page'), start=1):
        pages.append({
            'page': pi,
            'w': float(page.get('width')),
            'h': float(page.get('height')),
            'rows': rows_of(page),
        })

    def build(code, price, px, section, page, ws):
        finish = ' '.join(
            w['t'] for w in ws
            if w['x0'] > code['x1'] and w['x0'] < px - 1
            and not PRICE_RE.match(w['t']) and not PRICE_ATTACHED_RE.match(w['t'])
            and w['t'] not in ('PLN', 'NET', 'mm', 'x')
        )
        finish = re.sub(r'\s+', ' ', finish).strip()
        return {
            'code': code['t'], 'price': price, 'finish': finish, 'page': page,
            'x': round(code['x0'], 2), 'y': round(code['y0'], 2),
            'w': round(code['x1'] - code['x0'], 2), 'h': round(code['y1'] - code['y0'], 2),
            'section': section, '_px': px,
        }

    products = []
    for p in pages:
        # section = big top-left header (collection name)
        section = ''
        for r in p['rows'][:3]:
            left = [w['t'] for w in r['words'] if w['x1'] < 240]
            txt = ' '.join(left).strip()
            if txt and 'PLN' not in txt and 'ZDJ' not in txt and 'OPIS' not in txt:
                section = txt
                break
        page_on_req = any(
            'zamówienie' in ' '.join(w['t'] for w in r['words']).lower()
            for r in p['rows'][:8]
        )
        rows = []
        for r in p['rows']:
            ws = r['words']
            # collect price tokens on this row; prefer currency-backed values
            cur_prices = []
            bare_prices = []
            for i, w in enumerate(ws):
                attached = PRICE_ATTACHED_RE.match(w['t'])
                if attached:
                    val, base, cur = attached.group(1), w['x0'], True
                elif PRICE_RE.match(w['t']) and i + 1 < len(ws) and ws[i + 1]['t'] in CURRENCY:
                    val, base, cur = w['t'], w['x0'], True
                elif PRICE_RE.match(w['t']) and re.search(r'[.,]\d{2}$', w['t']):
                    val, base, cur = w['t'], w['x0'], False
                else:
                    continue
                j = i - 1
                while j >= 0 and re.match(r'^\d{1,3}$', ws[j]['t']) and (ws[j + 1]['x0'] - ws[j]['x1']) < 8:
                    val = ws[j]['t'] + ' ' + val
                    base = ws[j]['x0']
                    j -= 1
                (cur_prices if cur else bare_prices).append({'val': val, 'x0': base})
            prices = cur_prices if cur_prices else bare_prices
            if not prices:  # "na zapytanie" acts as a price anchor at its x
                zt = next((w for w in ws if w['t'].lower() == 'zapytanie'), None)
                if zt:
                    prices = [{'val': 'zapytanie', 'x0': zt['x0']}]
            rows.append({'ws': ws, 'prices': prices,
                         'codes': [w for w in ws if is_code(w['t'], w['x0'])]})

        # first pass: priced rows; remember families that carry a price on this page
        priced_bases = set()
        for rr in rows:
            ws, prices, codes = rr['ws'], rr['prices'], rr['codes']
            if not codes or not prices:
                continue
            for pr in prices:
                left = [c for c in codes if c['x1'] <= pr['x0'] + 1]
                if not left:
                    continue
                code = max(left, key=lambda c: c['x0'])
                products.append(build(code, pr['val'], pr['x0'], section, p['page'], ws))
                priced_bases.add(code['t'].rsplit('-', 1)[0])
        # second pass: on request-only pages keep every code; elsewhere keep an
        # unpriced code only if it is a sibling finish of a priced family here
        page_has_price = any(rr['prices'] for rr in rows)
        for rr in rows:
            if not rr['codes'] or rr['prices']:
                continue
            if page_on_req and not page_has_price:
                for code in rr['codes']:
                    products.append(build(code, 'zapytanie', 10 ** 9, section, p['page'], rr['ws']))
            elif any(len(c['t'].split('-')) >= 3 and c['t'].rsplit('-', 1)[0] in priced_bases
                     for c in rr['codes']):
                for code in rr['codes']:
                    products.append(build(code, 'zapytanie', 10 ** 9, section, p['page'], rr['ws']))

    # keep one entry per code, preferring the real (priced / on-request) listing
    def score(it):
        return (2 if it['price'] and it['price'] != 'zapytanie' else (1 if it['price'] else 0), -it['_px'])

    best = {}
    order = []
    for it in products:
        c = it['code']
        if c not in best:
            best[c] = it
            order.append(c)
        elif score(it) > score(best[c]):
            best[c] = it
    out = [best[c] for c in order]
    for it in out:
        it.pop('_px', None)

    json.dump(out, open('products_raw.json', 'w'), ensure_ascii=False, indent=0)
    print('codes:', len(out),
          '| priced:', sum(1 for i in out if i['price'] and i['price'] != 'zapytanie'),
          '| on-request:', sum(1 for i in out if i['price'] == 'zapytanie'),
          '| no-price:', sum(1 for i in out if not i['price']))
    for i in out:
        if i['code'].startswith('MW2N-950'):
            print(json.dumps(i, ensure_ascii=False))


if __name__ == '__main__':
    main()
