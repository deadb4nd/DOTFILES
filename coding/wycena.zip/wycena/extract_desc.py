#!/usr/bin/env python3
"""Attach the left-column 'OPIS TOWARU' description to each product code."""
import json, re, xml.etree.ElementTree as ET

NS = '{http://www.w3.org/1999/xhtml}'
HEADER = {'ZDJĘCIE', 'OPIS', 'TOWARU', 'CENA', 'KOD', 'WYKOŃCZENIE', 'MATERIAŁ', 'GRUBOŚĆ'}


def load_pages(path):
    data = open(path, 'rb').read()
    data = re.sub(rb'[\x00-\x08\x0b\x0c\x0e-\x1f]', b'', data)
    data = re.sub(rb'&(?![a-zA-Z]+;|#\d+;)', b'&amp;', data)
    root = ET.fromstring(data)
    pages = {}
    for pi, pg in enumerate(root.iter(NS + 'page'), 1):
        words = []
        for w in pg.iter(NS + 'word'):
            t = (w.text or '').strip()
            if not t:
                continue
            words.append((float(w.get('yMin')), float(w.get('xMin')), float(w.get('xMax')), t))
        pages[pi] = words
    return pages


def left_lines(words):
    """Group left-column words (x < 245) into text lines."""
    ws = [w for w in words if w[2] < 245 and 95 < w[0] < 790]
    ws.sort(key=lambda w: (w[0], w[1]))
    lines = []
    for y, x0, x1, t in ws:
        placed = False
        for ln in lines:
            if abs(ln['y'] - y) <= 3.2 and t not in HEADER:
                ln['w'].append((x0, t))
                n = len(ln['w'])
                ln['y'] = (ln['y'] * (n - 1) + y) / n
                placed = True
                break
        if not placed:
            lines.append({'y': y, 'w': [(x0, t)]})
    out = []
    for ln in lines:
        ln['w'].sort()
        text = ' '.join(t for _, t in ln['w']).strip()
        if not text or all(t in HEADER for _, t in ln['w']):
            continue
        if re.match(r'^\d{1,3}$', text):  # page number
            continue
        out.append({'y': ln['y'], 'text': text})
    out.sort(key=lambda l: l['y'])
    return out


def main():
    products = json.load(open('products_raw.json'))
    pages = load_pages('cennik_bbox.xml')

    by_page = {}
    for p in products:
        by_page.setdefault(p['page'], []).append(p)

    for page, items in by_page.items():
        items.sort(key=lambda p: p['y'])
        # cluster code rows into product blocks (gap > 30 pt)
        blocks = []
        for p in items:
            if blocks and p['y'] - blocks[-1]['maxy'] <= 30:
                blocks[-1]['items'].append(p)
                blocks[-1]['maxy'] = p['y']
            else:
                blocks.append({'items': [p], 'miny': p['y'], 'maxy': p['y']})
        lines = left_lines(pages.get(page, []))
        # assign each description line to the nearest block range
        for ln in lines:
            best, bestd = None, 1e9
            for b in blocks:
                if b['miny'] - 6 <= ln['y'] <= b['maxy'] + 12:
                    d = 0
                else:
                    d = min(abs(ln['y'] - b['miny']), abs(ln['y'] - b['maxy']))
                if d < bestd:
                    bestd, best = d, b
            if best is not None and bestd < 90:
                best.setdefault('desc', []).append(ln['text'])
        for b in blocks:
            desc = ' '.join(b.get('desc', []))
            desc = re.sub(r'\s+', ' ', desc).strip()
            for p in b['items']:
                p['desc'] = desc

    for p in products:
        p.setdefault('desc', '')

    json.dump(products, open('products_raw.json', 'w'), ensure_ascii=False, indent=0)
    with_desc = sum(1 for p in products if p['desc'])
    print('products:', len(products), '| with description:', with_desc)
    print('--- page 154 ---')
    for p in products:
        if p['page'] == 154:
            print(p['code'], '::', p['desc'][:70])


if __name__ == '__main__':
    main()
