#!/usr/bin/env python3
"""Turn products_raw.json into a compact products.js used by the web app."""
import json

raw = json.load(open('products_raw.json'))
out = []
for p in raw:
    out.append({
        'code': p['code'],
        'price': p['price'],
        'info': p['finish'],
        'desc': p.get('desc', ''),
        'page': p['page'],
        'x': p['x'],
        'y': p['y'],
        'w': p['w'],
        'h': p['h'],
        'group': p['section'],
    })

with open('products.js', 'w') as f:
    f.write('// Auto-generated from CENNIK-2026 CDA.pdf - do not edit by hand.\n')
    f.write('window.PRODUCTS = ')
    json.dump(out, f, ensure_ascii=False, separators=(',', ':'))
    f.write(';\n')

print('wrote products.js with', len(out), 'products')
