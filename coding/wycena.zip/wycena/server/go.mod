module cennik-serwer

go 1.21
