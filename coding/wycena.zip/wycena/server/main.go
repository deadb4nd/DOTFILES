package main

import (
	"fmt"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"time"
)

func main() {
	root, err := exeDir()
	if err != nil {
		root = "."
	}

	var ln net.Listener
	var port int
	for p := 8765; p <= 8785; p++ {
		ln, err = net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", p))
		if err == nil {
			port = p
			break
		}
	}
	if ln == nil {
		fmt.Println("Nie udalo sie uruchomic serwera (wszystkie porty zajete).")
		pause()
		return
	}

	url := fmt.Sprintf("http://localhost:%d/", port)
	handler := http.FileServer(http.Dir(root))

	srv := &http.Server{Handler: noCache(handler)}
	go func() {
		time.Sleep(300 * time.Millisecond)
		openBrowser(url)
	}()

	fmt.Println("==============================================")
	fmt.Println("  CENNIK 2026 - katalog z koszykiem")
	fmt.Println("----------------------------------------------")
	fmt.Println("  Adres: " + url)
	fmt.Println("  Zamknij to okno, aby zatrzymac program.")
	fmt.Println("==============================================")

	if err := srv.Serve(ln); err != nil {
		fmt.Println("Blad serwera:", err)
		pause()
	}
}

func exeDir() (string, error) {
	exe, err := os.Executable()
	if err != nil {
		return "", err
	}
	return filepath.Dir(exe), nil
}

func noCache(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-store")
		h.ServeHTTP(w, r)
	})
}

func openBrowser(url string) {
	exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
}

func pause() {
	fmt.Println("\nNacisnij Enter, aby zamknac...")
	fmt.Scanln()
}
