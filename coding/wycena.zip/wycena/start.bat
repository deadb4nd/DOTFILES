@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title CENNIK 2026 - katalog z koszykiem

if not exist "serwer.exe" goto noexe
if not exist "index.html" goto nofiles

echo ==============================================
echo   CENNIK 2026 - katalog z koszykiem
echo ----------------------------------------------
echo   Uruchamianie lokalnego serwera...
echo   Przegladarka otworzy sie automatycznie.
echo.
echo   ZAMKNIJ TO OKNO, aby zatrzymac program.
echo ==============================================
echo.

serwer.exe

echo.
echo Serwer zatrzymany.
pause
exit /b 0

:noexe
echo.
echo BLAD: nie znaleziono pliku serwer.exe w tym folderze.
echo Upewnij sie, ze plik start.bat i serwer.exe sa razem.
echo.
pause
exit /b 1

:nofiles
echo.
echo BLAD: nie znaleziono pliku index.html.
echo Uruchom start.bat z folderu, w ktorym sa wszystkie pliki katalogu.
echo.
pause
exit /b 1
