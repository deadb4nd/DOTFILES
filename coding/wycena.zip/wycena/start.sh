#!/usr/bin/env bash
# Serve the price list + cart app locally (no backend, just static files).
cd "$(dirname "$0")" || exit 1
PORT="${1:-8000}"
echo "Otwórz: http://localhost:$PORT"
echo "Zatrzymaj: Ctrl+C"
python3 -m http.server "$PORT"
